﻿using Microsoft.AspNetCore.Mvc;

namespace Web05_Nhom11.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class DashboardController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
